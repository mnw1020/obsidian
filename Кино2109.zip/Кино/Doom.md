---
Название: Doom
Просмотрено: 2015-05-26
Оценка: "5"
Оценка Imdb: "5.2"
Оценка Кинопоиск: 5.9
Количество голосов Кинопоиск: 104893
Количество голосов Imdb: 125032
tags:
  - movies
Жанр:
  - Sci-Fi
Релиз: 2005-10-20
Время: 105 min
Режисер:
  - Andrzej Bartkowiak

Роли файл: "Кино/_system/Роли/Doom.роли.md"
Описание: 2045 год. После того как из далёкой научной лаборатории Олдуай был получен сигнал о помощи, на Марс прибывает отряд космического спецназа и обнаруживает разгромленную станцию. Вскоре выясняется, что на людей здесь охотятся полчища ужасных мутантов.
imdb Id: tt0419706
poster: https://m.media-amazon.com/images/M/MV5BYjA5ZGQ1MDQtMGI0ZC00ZDY4LTg1NmYtNzgwNGE3MjQ0MzYyXkEyXkFqcGc@._V1_SX300.jpg

Кинопоиск ID: "84140"
---
<!-- KINO:ROLES:EMBED:V1 -->
![[Кино/_system/Роли/Doom.роли]]
![](https://m.media-amazon.com/images/M/MV5BYjA5ZGQ1MDQtMGI0ZC00ZDY4LTg1NmYtNzgwNGE3MjQ0MzYyXkEyXkFqcGc@._V1_SX300.jpg)
