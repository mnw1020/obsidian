---
Название: X
Просмотрено: 2022-05-25
Оценка: "2"
Оценка Imdb: "6.5"
Оценка Кинопоиск:
Количество голосов Кинопоиск:
Количество голосов Imdb: 228747
tags:
  - movies
Жанр:
  - Horror
  - Mystery
Релиз: 2022-03-17
Время: 105 min
Режисер:
  - Ti West

Роли файл: "Кино/_system/Роли/X.роли.md"
Описание: 1979 год, Техас. Компания из шести человек арендует небольшой дом у пожилой пары фермеров, чтобы снимать фильм для взрослых. Хотя хозяин недвижимости сразу предупреждает, чтобы приезжие не шумели и вели себя прилично, продюсер, разумеется, пренебрегает его просьбой. Вскоре выяснится, что старички не такие безобидные, как казалось на первый взгляд.
imdb Id: tt13560574
poster: https://m.media-amazon.com/images/M/MV5BODUwYTNhMTMtYWQ5Ny00YTdmLWIxOTAtNDczNzVlYzg2NDFkXkEyXkFqcGc@._V1_SX300.jpg

Кинопоиск ID: "4382899"
---
<!-- KINO:ROLES:EMBED:V1 -->
![[Кино/_system/Роли/X.роли]]
![](https://m.media-amazon.com/images/M/MV5BODUwYTNhMTMtYWQ5Ny00YTdmLWIxOTAtNDczNzVlYzg2NDFkXkEyXkFqcGc@._V1_SX300.jpg)
