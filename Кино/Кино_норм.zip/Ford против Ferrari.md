---
Название: Ford v Ferrari
Просмотрено: 2021-02-22
Оценка: "8"
Оценка Imdb: "8.1"
Оценка Кинопоиск: 8.2
Количество голосов Кинопоиск: 714772
Количество голосов Imdb: 586698
tags:
  - movies
Жанр:
  - Biography
Релиз: 2019-11-13
Время: 152 min
Режисер:
  - James Mangold
Актеры:
  - Adam Mayfield
  - Alan Cevallos
  - Alec Taylor
  - Alex Gurney
  - Alex Leontev
  - Alex Wexo
  - Alfredo Tavares
  - Alyona Khmara
  - Americo Galli
  - Andrew Buckland
  - Andrew Burlinson
  - Andy Morales
  - Angelo Dibello
  - Anton Nassif
  - Arianna Tysinger
  - Arron Shiver
  - Arthur J. Gonzales
  - Aylam Orian
  - Az Rudman
  - Ben Collins
  - Benjamin Rigby
  - Blake Seltzer
  - Bogdan Szumilas
  - Bonnie Antonini
  - Brad Beyer
  - Brad McCabe
  - Brandon Irvin
  - Brea Bee
  - Brenden Roberts
  - Brent Pontin
  - Bridie Latona
  - Brooklyn McDaris
  - Bruce M. Stockert
  - Cailan Robinson
  - Caitríona Balfe
  - Cambria Elise
  - Cameron Hennings
  - Cameron West
  - Camillo Faieta
  - Carl Collanus
  - Chris Markle
  - Chris Spinelli
  - Chris Wodniak
  - Chris Yarrow
  - Christian Bale
  - Christopher Darga
  - Clément Larue
  - Corey Crandall
  - Corrado Invernizzi
  - Craig Frosty Silva
  - Dallin McKay
  - Daniel Aryeh Lewis
  - Daniel Bondor
  - Darin Cooper
  - Darren Jacobs
  - Darrin Prescott
  - Daryl Deino
  - Dave Marandola
  - David Cohen
  - David Horton
  - David John Kernick
  - David Michael-Smith
  - David Rona
  - David Yorr
  - Drew Rausch
  - Dylan James Boland
  - Edwin Modlin II
  - Elizabeth Dement
  - Ellis Eckles
  - Emil Beheshti
  - Emmeline Luka Bale
  - Eric Paterniani
  - Eric Warwick
  - Erik-Jan Pliner
  - Evan Arnold
  - Evin Charles Anderson
  - Fatimah Hassan
  - Forrest Jade
  - Francesco Bauco
  - Garth Wynne-Jones
  - Gary Sievers
  - George Morris
  - Gian Franco Tordi
  - Gianni Ullio
  - Giles Matthey
  - Giovanni Cirfiera
  - Giulia Da Pian
  - Grace Fae
  - Guido Cocomello
  - Hugh Benjamin
  - Hunter Jones
  - Ian Harding
  - Jack McMullen
  - Jake Ersek
  - Jake Ingrande
  - James Karroum
  - James Tappan
  - James Tyler Paulson
  - Jan Munroe
  - Jason Breznikar
  - Jean-Pierre Giagnoli
  - Jedediah Jenk
  - Jeff Burhans
  - Jeff Goins
  - Jeff M Hill
  - Jeff Winn
  - Jenelle McKee
  - Jeremy Zaugg
  - Jim Marsilio
  - JJ Feild
  - Joe Don Harris
  - Joe Williamson
  - Jon Bernthal
  - Jon Ueberroth
  - Jon Zepp
  - Jonathan LaPaglia
  - Jorge Cevallos
  - Josh Lucas
  - Joshua Bankey
  - Joss Glennie-Smith
  - Julian Miller
  - Justin Nardine
  - Kai Andersen
  - Katelynn Dubow
  - Kelsey Deroian
  - Kelsey June Jensen
  - Kevin Fleenor
  - Kirt Kishita
  - Kyle A. Bell
  - Lachlan Buchanan
  - Landon Perry
  - Larsen Deane
  - Leif Carlgren
  - Lily Winn
  - Linda Victoria Romo
  - Lou Beatty Jr.
  - Louis Fasanaro
  - Luiggi Debiasse
  - Luke Matheis
  - Luna J Munroe
  - Mahin Iqbal
  - Mallory Mckenzie
  - Marc Forget
  - Mario Di Donato
  - Marisa Petroro
  - Mark Krenik
  - Mark Stepanek
  - Matt Damon
  - Matt Duran
  - Matt Freeman
  - Merryn Landry
  - Michael DeBartolo
  - Michael Kobulnicky
  - Michael Lanahan
  - Michael Wayne Brown
  - Molly Malin
  - Morgan Combes
  - Noah Jupe
  - Olivier Blin
  - Ottavio Taddei
  - Paul Alan Dixon
  - Paul Fenech
  - Paul Fox
  - Peter Arpesella
  - Philip Harville
  - Pierre Léon Luneau
  - Ray McKinnon
  - Remo Girone
  - Riad Sattouf
  - Rick L. Dean
  - Roberta Sparta
  - Rudolf Martin
  - Ryan O'Dell
  - Rylee Ryan
  - Ryna Nevius
  - Sabina Nogic
  - Sam Fusaro
  - Samuel M. Lewis
  - Sandy Burhans
  - Sarah Dale
  - Sarah Jarman
  - Savannah Cruz
  - Scott Rapp
  - Sean Carrigan
  - Sean Renzetti
  - Sergi Cervera
  - Shawn Law
  - Skyler Marshall
  - Stanley Kowalski
  - Stefania Spampinato
  - Stephane Fiorenza
  - Steven Ziel
  - Tanner Foust
  - Thomas John Rudolph
  - Tim Banning
  - Tomer David
  - Tracy Letts
  - Trent Walker
  - Troy Dillinger
  - Vernon Dew
  - Vincent Di Paolo
  - Wallace Langham
  - Ward Horton
  - William Myers
  - Wyatt Nash
  - Zachary Chicos
  - Zack Zublena
Описание: В начале 1960-х Генри Форд II принимает решение улучшить имидж компании и сменить курс на производство более модных автомобилей. После неудавшейся попытки купить практически банкрота Ferrari американцы решают бросить вызов итальянским конкурентам на трассе и выиграть престижную гонку 24 часа Ле-Мана. Чтобы создать подходящую машину, компания нанимает автоконструктора Кэррола Шэлби, а тот отказывается работать без выдающегося, но, как считается, трудного в общении гонщика Кена Майлза. Вместе они принимаются за разработку впоследствии знаменитого спорткара Ford GT40.
imdb Id: tt1950186
poster: https://m.media-amazon.com/images/M/MV5BOTBjNTEyNjYtYjdkNi00YzE5LTljYzUtZjVlYmYwZmJmZWYxXkEyXkFqcGc@._V1_.jpg
Роли актеров:
  - Aeronutronics Chief Engineer - Emil Beheshti
  - Agnelli - Giovanni Cirfiera
  - Agnelli Guest - Cambria Elise
  - Agnelli Italian Party Guest - Linda Victoria Romo
  - Agnelli Secretary - Gian Franco Tordi
  - Al 'Gus' Scussel - Shawn Law
  - Alpine Executive - Riad Sattouf
  - Australian Man Race Audience / Le Mans Fan - Paul Fenech
  - Autograph Seeker - Cameron Hennings
  - Bob Bondurant - Darrin Prescott
  - Box Spectator - Philip Harville
  - Boy In Crowd - Mahin Iqbal
  - British Commentator - Darren Jacobs
  - British Commentator - Paul Fox
  - British Ford Engineer - Joe Don Harris
  - Bruce McLaren - Benjamin Rigby
  - Brumos Executive - Michael Lanahan
  - Bucknum - Tanner Foust
  - Carroll Shelby - Matt Damon
  - Celebrity MC - Cloverfield - Lachlan Buchanan
  - Charlie Agapiou - Jack McMullen
  - Charlie Brockman ABC - Arron Shiver
  - Cheering Spectator - Dallin McKay
  - Chris Amon - Brent Pontin
  - Claudia Cardinale - Bridie Latona
  - Cool Young Buyer - Wyatt Nash
  - Dan Gurney - Alex Gurney
  - Denny Hulme - Ben Collins
  - Dieter Voss - Rudolf Martin
  - Don Frey - Joe Williamson
  - Dr. Granger - Wallace Langham
  - Driver / Bartender - Arthur J. Gonzales
  - Driver / Pedestrian - Fatimah Hassan
  - Drunk Man Singing - Olivier Blin
  - Edwin Turley - Jan Munroe
  - Enzo Ferrari - Remo Girone
  - Eric Broadley - Julian Miller
  - Executive Box Spectator - Ellis Eckles
  - Factory Worker - Samuel M. Lewis
  - Factory Worker - Sergi Cervera
  - Factory Worker / Score Keeper - James Karroum
  - Female Spectator - Kelsey Deroian
  - Female Spectator - Mallory Mckenzie
  - Ferrari Driver - Chris Yarrow
  - Ferrari Factory Engine Builder - Louis Fasanaro
  - Ferrari Factory Worker - Chris Spinelli
  - Ferrari Factory Worker - Vincent Di Paolo
  - Ferrari Factory Worker / Pit Crew - Jean-Pierre Giagnoli
  - Ferrari Guest - Roberta Sparta
  - Ferrari Lawyer - Mario Di Donato
  - Ferrari Owner - Michael DeBartolo
  - Ferrari Pit / Box Girl - Giulia Da Pian
  - Ferrari Pit Chief - Peter Arpesella
  - Ferrari Pit Crew - Alan Cevallos
  - Ferrari Pit Crew - Sean Renzetti
  - "Ferrari Pit Crew #1 - Camillo Faieta"
  - "Ferrari Pit Crew #2 - Angelo Dibello"
  - Ferrari Pit Driver - Kyle A. Bell
  - Ferrari Pit Leader - Hunter Jones
  - Ferrari Secretary - Bonnie Antonini
  - Ferrari's English Translator - Stefania Spampinato
  - Finish Line Racing Enthusiast - Chris Wodniak
  - Flag Boy - Corey Crandall
  - Flag Boy - Landon Perry
  - Flagger (Daytona) - Jeff Winn
  - Floor Manager - Michael Wayne Brown
  - Ford Box Spectator - Sabina Nogic
  - Ford Box Woman - Brooklyn McDaris
  - Ford Driver - Gary Sievers
  - Ford Exec Sean Reed - Leif Carlgren
  - Ford Executive - Cailan Robinson
  - Ford Executive - Dylan James Boland
  - Ford Executive - Erik-Jan Pliner
  - Ford Executive - Hugh Benjamin
  - Ford Executive - Ian - Ian Harding
  - Ford Executive - Justin Nardine
  - Ford Executive - Matt Freeman
  - Ford Executive - Troy Dillinger
  - "Ford Executive #2 - Andrew Burlinson"
  - "Ford Executive #2 - Steven Ziel"
  - "Ford Executive #4 - Vernon Dew"
  - "Ford Executive #22 - David John Kernick"
  - Ford Factory Worker / Holman Moody Pit - Jedediah Jenk
  - Ford Italian Translator - Gary - Luiggi Debiasse
  - Ford Mechanic - Luke Matheis
  - Ford Pit Driver - Jim Marsilio
  - Ford Pit Girl - Arianna Tysinger
  - Ford Secretary - Grace - Grace Fae
  - "Ford Secretary #1 - Elizabeth Dement"
  - "Ford Secretary #2 - Jenelle McKee"
  - Ford Spectator - Ryna Nevius
  - Ford Waitress - Sarah Jarman
  - Ford's Secretary - Katelynn Dubow
  - Franco Gozzi - Corrado Invernizzi
  - French Commentator - Zack Zublena
  - French Policeman - Stanley Kowalski
  - Frenchie / Ford Executive - William Myers
  - Gendarme - Joshua Bankey
  - Gendarme - Mark Stepanek
  - Gendarme - Matt Duran
  - Gendarme - Tomer David
  - Gendarme Soldier - Jason Breznikar
  - German Commentator - Aylam Orian
  - Guitar Player - Andy Morales
  - Henry Ford II - Tracy Letts
  - Hero Ferrari Box - Alfredo Tavares
  - Hero Ferrari Box - Gianni Ullio
  - Holman Moody Pit Crew - Alex Wexo
  - Holman Moody Pit Crew - Trent Walker
  - Holman Moody Pit Crew / Ford Factory Worker - Alex Leontev
  - Holman Moody Pit Crew / Ford Factory Worker - Garth Wynne-Jones
  - Impala Dad - Cameron West
  - "IRS Employee #1 - James Tappan"
  - "IRS Employee #2 - Ryan O'Dell"
  - Italian Photographer - Ottavio Taddei
  - Janitor - Lou Beatty Jr.
  - Japanese Commentator - Kirt Kishita
  - Jerry Grant - Daryl Deino
  - John Holman - Christopher Darga
  - Ken - Edwin Modlin II
  - Ken Miles - Christian Bale
  - Kid Program Seller - Clément Larue
  - Lance Reventlow - Giles Matthey
  - Le Mans Flower Girl - Emmeline Luka Bale
  - "Le Mans Official #1 - Marc Forget"
  - "Le Mans Official #2 - Stephane Fiorenza"
  - Le Mans Race Spectator - Jeff Burhans
  - Le Mans Race Spectator - Sandy Burhans
  - Le Mans Spectator - Rylee Ryan
  - Lee Iacocca - Jon Bernthal
  - Leo Beebe - Josh Lucas
  - Lloyd Ruby - Adam Mayfield
  - Lorenzo Bandini - Francesco Bauco
  - Ludo Scarfiotti - Guido Cocomello
  - Male Box Spectator - Zachary Chicos
  - Man on Street - Brenden Roberts
  - Mario Andretti - Jon Zepp
  - Mechanic Ford Advanced Vehicles - Joss Glennie-Smith
  - Mollie Miles - Caitríona Balfe
  - Mrs. Henry Ford - Marisa Petroro
  - Pedestrian - Rick L. Dean
  - Peter Miles - Noah Jupe
  - Phil Hill - James Tyler Paulson
  - Phil Remington - Ray McKinnon
  - Photographer - Az Rudman
  - Photographer - Blake Seltzer
  - Photographer - Carl Collanus
  - Photographer - David Yorr
  - Photographer with Vespa - Pierre Léon Luneau
  - Pilot Private Plane - Drew Rausch
  - Pit Crew - Chris Markle
  - Pit Crew - Jeff M Hill
  - Pit Crew / Factory Worker - Jeremy Zaugg
  - Pit Engineer - Eddie - Jonathan LaPaglia
  - Pit Marshall - David Cohen
  - Police Officer - Scott Rapp
  - Porsche Pit Crew - Anton Nassif
  - Press Camera Operator - Jake Ingrande
  - Production Line Foreman - Jon Ueberroth
  - Race Audience - Evin Charles Anderson
  - Race Enthusiast - Eric Warwick
  - Race Photographer - David Michael-Smith
  - Race Spectator - Sarah Dale
  - Raceway Guest - Bruce M. Stockert
  - Raceway Guest - Forrest Jade
  - Raceway Guest - Luna J Munroe
  - Raceway Guest - Savannah Cruz
  - Reporter - Alec Taylor
  - Reporter - Americo Galli
  - Reporter - Daytona - Tim Banning
  - Reporter - Kevin Fleenor
  - Reporter - Michael Kobulnicky
  - Reporter - Sam - Darin Cooper
  - Reporter / Race Spectator - Daniel Bondor
  - Reporter / TV Crew - Paul Alan Dixon
  - Roy Lunn - JJ Feild
  - Santa Monica Reporter - Jake Ersek
  - SCCA Official - Evan Arnold
  - Scuderia Ferrari - Bogdan Szumilas
  - Secratary - Merryn Landry
  - Shelby Cobra Worker - Dave Marandola
  - Shelby Crew - Brandon Irvin
  - Shelby Pit Big Mug - Thomas John Rudolph
  - Shelby Pit Crew - Brad McCabe
  - Shelby Pit Crew - Frosty - Craig Frosty Silva
  - Shelby Pit Crew - Jeff Goins
  - Shelby Pit Crew - Jorge Cevallos
  - Shelby Pit Crew - Morgan Combes
  - Shelby Pit Crew - Ronnie Larson - Larsen Deane
  - Shelby Pit Crew - Sam Fusaro
  - Shelby Pit Crew - Skyler Marshall
  - Shelby Pit Guest - David Horton
  - Shelby Pit Smokey - Mark Krenik
  - Shelby Pitcrew - Kai Andersen
  - Shelby's Secretary - Alyona Khmara
  - Spectator - David Rona
  - Spectator - Eric Paterniani
  - Spectator - George Morris
  - Spectator - Lily Winn
  - Sports Announcer - Andrew Buckland
  - Test Driver - Burt - Ward Horton
  - Tiki Bar Waitress - Brea Bee
  - Umberto Agnelli - Daniel Aryeh Lewis
  - Waitress - Kelsey June Jensen
  - Waitress - Molly Malin
  - Walt Hansgen - Sean Carrigan
  - Wayne (Customer) - Brad Beyer
Кинопоиск ID: "835086"
---
<!-- KINO:ENTITY:LINKS:V3 -->
```dataviewjs
const KINO_ENTITY_FIELDS = [
    ["Режисер", "Режиссер", "Кино - Открыть режиссера"],
    ["Актеры", "Актеры", "Кино - Открыть актера"],
    ["Жанр", "Жанры", "Кино - Открыть жанр"]
];

function kinoText(value) { return String(value ?? "").trim().normalize("NFC"); }
function kinoValues(value) {
    return [...new Set((Array.isArray(value) ? value : [value]).map(kinoText).filter(Boolean))];
}
function kinoName(value) {
    const text = kinoText(value);
    const actorNames = kinoValues(dv.current()["Актеры"]);
    const known = actorNames.find(name =>
        text === name || text.startsWith(name + " - ") || text.endsWith(" - " + name)
    );
    if (known) return known;
    return text.includes(" - ") ? text.split(/\s+-\s+/).slice(-1)[0].trim() : text;
}
function kinoUri(choice, value) {
    return "obsidian://quickadd?vault=" + encodeURIComponent(app.vault.getName())
        + "&choice=" + encodeURIComponent(choice)
        + "&value-entity=" + encodeURIComponent(value);
}

const actorRoles = kinoValues(dv.current()["Роли актеров"]);
const root = dv.container.createDiv({ cls: "kino-entity-links" });
for (const [field, label, choice] of KINO_ENTITY_FIELDS) {
    const row = root.createDiv({ cls: "kino-entity-links-row" });
    row.createEl("strong", { text: label + ": " });
    const values = field === "Актеры"
        ? (actorRoles.length ? actorRoles : kinoValues(dv.current()[field]))
        : kinoValues(dv.current()[field]);
    if (!values.length) { row.appendText("Не указано"); continue; }
    if (field === "Актеры") {
        values.forEach(value => {
            const line = row.createDiv({ cls: "kino-entity-link-line" });
            const link = line.createEl("a");
            link.textContent = value;
            link.href = kinoUri(choice, kinoName(value));
        });
        continue;
    }
    values.forEach((value, index) => {
        if (index) row.appendText(" · ");
        const link = row.createEl("a");
        link.textContent = value;
        link.href = kinoUri(choice, value);
    });
}
```
---
![](https://m.media-amazon.com/images/M/MV5BOTBjNTEyNjYtYjdkNi00YzE5LTljYzUtZjVlYmYwZmJmZWYxXkEyXkFqcGc@._V1_.jpg)
