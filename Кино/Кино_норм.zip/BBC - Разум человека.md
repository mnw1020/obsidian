---
Название: "BBC: The Human Mind"
Просмотрено: 2013-10-27
Оценка: "4"
Оценка Imdb: ""
Оценка Кинопоиск: 7.4
Количество голосов Кинопоиск: 185
Количество голосов Imdb: null
tags:
  - serial
Жанр:
  - "Documentary"
Релиз: 2003-10-01
Время: 49 min
Режисер:
  - "Dzhoanna Gibbon (Джоанна Гиббон)"
  - "Nik Merfi (Ник Мерфи)"
Актеры: []
Описание: 📺 Почему один человек чувствует опасность, а другой нет? Как может опыт подсказать нам, стоит ли доверять людям? И как дети осваивают сложные движения, просто думая о них? Ответ кроется в самой удивительной части каждого из нас, в нашем разуме. Каждую секунду бодрствования, хотя мы даже и не осознаем этого, наш разум работает, изучая окружающий мир. Но наша способность к познанию даже больше, чем мы думаем. Изучая принципы работы разума мы можем улучшить нашу познавательную способность и раскрыть свой истинный потенциал. Человек добился огромных успехов в изучении своего тела. Но разум человека до сих пор остается загадкой. Новый документальный фильм ВВС попытается найти ответ, как работает разум человека, и как его можно использовать с максимальной эффективностью.
imdb Id:
poster:
---
<!-- KINO:ENTITY:LINKS:V2 -->
```dataviewjs
const KINO_GENRE_ALIASES = {"Боевик":["Action","Боевик"],"Приключения":["Adventure","Приключения"],"Анимация":["Animation","Анимация","Мультфильм"],"Биография":["Biography","Биография"],"Комедия":["Comedy","Комедия"],"Криминал":["Crime","Криминал"],"Документальный":["Documentary","Документальный","Документальное"],"Драма":["Drama","Драма"],"Семейный":["Family","Семейный"],"Фэнтези":["Fantasy","Фэнтези"],"История":["History","История"],"Ужасы":["Horror","Ужасы"],"Музыка":["Music","Музыка"],"Мюзикл":["Musical","Мюзикл"],"Мистика":["Mystery","Мистика"],"Мелодрама":["Romance","Мелодрама"],"Фантастика":["Sci-Fi","Science Fiction","Фантастика"],"Короткометражка":["Short","Short Film","Короткометражка"],"Спорт":["Sport","Sports","Спорт"],"Триллер":["Thriller","Триллер"],"Военный":["War","Военный"],"Реалити-шоу":["Reality-TV","Reality TV","Реалити-шоу"],"Вестерн":["Western","Вестерн"]};
const KINO_ENTITY_FIELDS = [
    ["Режисер", "Режиссер", "Кино - Открыть режиссера"],
    ["Актеры", "Актеры", "Кино - Открыть актера"],
    ["Жанр", "Жанры", "Кино - Открыть жанр"]
];

function kinoEntityText(value) {
    return String(value ?? "").trim().normalize("NFC");
}

function kinoPersonName(value) {
    return kinoEntityText(value).replace(/\s+-\s+.+$/, "").trim();
}

function kinoEntityKey(value) {
    return kinoEntityText(value).toLocaleLowerCase("ru").replace(/ё/g, "е");
}

function kinoCanonicalGenre(value) {
    const text = kinoEntityText(value);
    const key = kinoEntityKey(text);
    for (const [canonical, aliases] of Object.entries(KINO_GENRE_ALIASES)) {
        if ([canonical, ...aliases].some(alias => kinoEntityKey(alias) === key)) return canonical;
    }
    return text;
}

function kinoValues(value) {
    return [...new Set((Array.isArray(value) ? value : [value])
        .map(kinoEntityText).filter(Boolean))];
}

function kinoCanonical(field, value) {
    return field === "Жанр" ? kinoCanonicalGenre(value) : kinoEntityText(value);
}

function kinoUri(choice, value) {
    return "obsidian://quickadd?vault=" + encodeURIComponent(app.vault.getName())
        + "&choice=" + encodeURIComponent(choice)
        + "&value-entity=" + encodeURIComponent(value);
}

const kinoRoot = dv.container.createDiv({ cls: "kino-entity-links" });
for (const [field, label, choice] of KINO_ENTITY_FIELDS) {
    const groups = new Map();
    for (const original of kinoValues(dv.current()[field])) {
        const canonical = kinoCanonical(field, original);
        const key = kinoEntityKey(canonical);
        if (!groups.has(key)) groups.set(key, { label: canonical, originals: [] });
        groups.get(key).originals.push(original);
    }
    const row = kinoRoot.createDiv({ cls: "kino-entity-links-row" });
    row.createEl("strong", { text: label + ": " });
    if (!groups.size) {
        row.appendText("Не указано");
        continue;
    }
    [...groups.values()].forEach((group, index) => {
        if (field !== "Актеры" && index) row.appendText(" · ");
        const target = field === "Актеры" ? kinoPersonName(group.label) : group.label;
        const linkRow = field === "Актеры" ? row.createDiv({ cls: "kino-entity-link-line" }) : row;
        const link = linkRow.createEl("a");
        link.textContent = group.label;
        link.href = kinoUri(choice, target);
        if (group.originals.some(original => original !== group.label)) {
            link.title = "В YAML: " + group.originals.join(" / ");
        }
    });
}
```
---
