---
Название: "Harry Potter and the Deathly Hallows: Part 2"
Просмотрено: 2012-06-04
Оценка: "7"
Оценка Imdb: "8.1"
Оценка Кинопоиск: 8.1
Количество голосов Кинопоиск: 411612
Количество голосов Imdb: 1062749
tags:
  - movies
Жанр:
  - Fantasy
Релиз: 2011-07-07
Время: 130 min
Режисер:
  - David Yates
Актеры:
  - Aaron Virdee
  - Abram Welsh
  - Adam Alderman
  - Adam Brashaw
  - Adrian Rawlins
  - Afshan Azad
  - Aimee Holden
  - Alain Stash
  - Alan Bennett
  - Alan Rickman
  - Albert Tang
  - Alfie McIlwain
  - Alfred Camp
  - Alfred Enoch
  - Amber Evans
  - Amy Wiles
  - Andrew Herd
  - Andy Callaghan
  - Anna Shaffer
  - Annabelle Davis
  - Anthony Allgood
  - Ariella Paradise
  - Arthur Bowen
  - Arti Shah
  - Ashley Beaver
  - Ashley McGuire
  - Ben Champniss
  - Benedict Clarke
  - Benn Northover
  - Bertie Gilbert
  - Binde Johal
  - Blake Curtis-Woodcock
  - Bob Yves Van Hellenberg Hubar
  - Bonnie Wright
  - Brian Wheeler
  - Charlie Hobbs
  - Charlie Ryall
  - Chloé Bruce
  - Chloe Franks
  - Chris Chan
  - Chris Knight
  - Chris Rankin
  - Christian Black
  - Christian Coulson
  - Christina Low
  - Christoph Cordell
  - Ciarán Hinds
  - Clémence Poésy
  - Collet Collins
  - Courtney Fearon
  - Craig Garner
  - Curtis Rowland Small
  - Daniel Radcliffe
  - Daniella Farley
  - Daphne de Beistegui
  - Dave Legeno
  - David Barron
  - David Bradley
  - David Bulbeck
  - David Decio
  - David Heyman
  - David Ledger
  - David Thewlis
  - Dean Conder
  - Debra Leigh-Taylor
  - Devon Murray
  - Domhnall Gleeson
  - Elisabeth Roberts
  - Ellie Darcey-Alden
  - Emil Hostina
  - Emma Thompson
  - Emma Watson
  - Eva Loy
  - Evanna Lynch
  - Freddie Stroma
  - Gabriella Pond
  - Garry Sayer
  - Gary Oldman
  - Gemma Jones
  - Gemma Kayla
  - George Appleby
  - George Christodoulou
  - George Harris
  - Georgina Leonidas
  - Geraldine Somerville
  - Gideon Tekeste
  - Gilbert White
  - Gino Picciano
  - Gioacchino Jim Cuffaro
  - Glen Stanway
  - Grace Bruce
  - Grace Meurisse Francis
  - Graham Duff
  - Granville Saxton
  - Greg Doherty
  - Guy Henry
  - Harper Heyman
  - Harrison Davis
  - Hattie Gotobed
  - Hayley Burroughs
  - Hebe Beardsall
  - Helen McCrory
  - Helena Barlow
  - Helena Bonham Carter
  - Hrvoje Klecz
  - Ian Hart
  - Ian Peck
  - Ifeoma Oboko
  - Isabella Laughland
  - Isla Jane Selley
  - Israr Azam
  - Jade Callard
  - Jade Gordon
  - Jade Stanger
  - James Phelps
  - Jamie John
  - Jamie McLeod-Ross
  - Jason Isaacs
  - Jeff Lipman
  - Jennifer Clegg
  - Jessica Niles
  - Jessie Cave
  - Jim Broadbent
  - Joe Kallis
  - Johann Benét
  - John Hurt
  - John Warman
  - Jon Campling
  - Jon Key
  - Jonothon Masai
  - Jordan Coulson
  - Josh Bennett
  - Josh Herdman
  - Joshua Jo
  - Judith Sharp
  - Julie Walters
  - Kamilla Woodburn
  - Karen Anderson
  - Katie Leung
  - Katie Purvis
  - Keijo Salmela
  - Kelly Macdonald
  - Kelvin Wise
  - Laura Whitfield
  - Lauren Barrand
  - Leila Kotori
  - Leslie Phillips
  - Lily Tello
  - Lisa Osmond
  - Louis Cordice
  - Louisa Bettine
  - Louisa Warren
  - Lucy Chappell
  - Luke Newberry
  - Maggie Smith
  - Marianne Chase
  - Mark Dusty Miller
  - Mark Sealey
  - Mark Williams
  - Marta Royles
  - Mason Kayne
  - Matt Da Silva
  - Matthew Hodgkin
  - Matthew Lewis
  - Maxwell Laird
  - Melissa Gotobed
  - Michael Aston
  - Michael Gambon
  - Michael Henbury Ballan
  - Michael Thompson
  - Mike Edmonds
  - Miriam Margolyes
  - Nasir Mohamed
  - Natalia Tena
  - Natalie Hallam
  - Natalie Harrison
  - Nathan Barris
  - Nick Hopper
  - Nick Moran
  - Nick Turner
  - Nikki Bond
  - Nina Aimer Fox
  - Ninette Finch
  - Oliver Phelps
  - Paul Bailey
  - Paul Bateman
  - Paul Davies
  - Pauline Stone
  - Penelope McGhie
  - Persephone Muse
  - Peter Burroughs
  - Peter G. Reed
  - Peter Paul Burrows
  - Phil Holden
  - Phil Wright
  - Rachel Lin
  - Ralph Fiennes
  - Ralph Ineson
  - Rich Goble
  - Richard Trinder
  - Robbie Coltrane
  - Robin Harvey
  - Rohan Gotobed
  - Roseanna Brown
  - Ruby Evans
  - Rupert Grint
  - Rusty Goffe
  - Ryan Butcher
  - Ryan Turner
  - Ryan Webb
  - Samantha Davis
  - Sammy Measom
  - Samuel Supple
  - Sandeep Mohan
  - Sarah Bennett
  - Sarah Lowe
  - Sarah-Jane De Crespigny
  - Scarlett Hefner
  - Sean Biggerstaff
  - Sean Francis George
  - Sha'ori Morris
  - Sian Grace Phillips
  - Spencer Wilding
  - Steve Poulsen
  - Steve Redford
  - Steven Hopwood
  - Suzanne Toase
  - Thomas Alan Williamson
  - Tim Mcgill Grieveson
  - Timothy Shieff
  - Timothy Spall
  - Tobi Stubbs
  - Toby Papworth
  - Tom Felton
  - Tony Adkins
  - Tony Kirwood
  - Tony Montalbano
  - Valerie Dane
  - Victor Akintunde
  - Vinnie Clarke
  - Warwick Davis
  - Will Dunn
  - William Melling
  - Zoltan Adorjan
Описание: В грандиозной последней главе битва между добрыми и злыми силами мира волшебников перерастает во всеобщую войну. Ставки ещё никогда не были так высоки, а поиск убежища — столь сложен. И быть может именно Гарри Поттеру придется пожертвовать всем в финальном сражении с Волан-де-Мортом. Способен ли наш герой спасти мир? И всё закончится здесь.
imdb Id: tt1201607
poster: https://m.media-amazon.com/images/M/MV5BOTA1Mzc2N2ItZWRiNS00MjQzLTlmZDQtMjU0NmY1YWRkMGQ4XkEyXkFqcGc@._V1_SX300.jpg
Франшиза: "[[Кино/Франшизы/Волшебный мир Гарри Поттера]]"
Роли актеров:
  - Aberforth Dumbledore - Ciarán Hinds
  - Aged Gringotts' Goblin - Rusty Goffe
  - Albus Severus Potter - 19 Years Later - Arthur Bowen
  - Alecto Carrow - Suzanne Toase
  - Amycus Carrow - Ralph Ineson
  - Argus Filch - David Bradley
  - Ariana Dumbledore - Hebe Beardsall
  - Arthur Weasley - Mark Williams
  - Astoria Malfoy - 19 Years Later - Jade Gordon
  - Augusta Longbottom - Ninette Finch
  - Augustus Rookwood - Richard Trinder
  - Auror - Tim Mcgill Grieveson
  - Baby Harry Potter - Toby Papworth
  - Baby of Dining Wizard Family in Portrait - Harper Heyman
  - Bearded Wizard in Portrait - Peter Paul Burrows
  - Bellatrix Lestrange - Helena Bonham Carter
  - Bill Weasley - Domhnall Gleeson
  - Blaise Zabini - Louis Cordice
  - Bogrod - Jon Key
  - Chief Snatcher - David Decio
  - Cho Chang - Katie Leung
  - Commuter on Platform 13 and 3 / 4 - David Bulbeck
  - Cormac McLaggen - Freddie Stroma
  - Dean Thomas - Alfred Enoch
  - Death Eater - Alain Stash
  - Death Eater - Ashley Beaver
  - Death Eater - Ashley McGuire
  - Death Eater - Bob Yves Van Hellenberg Hubar
  - Death Eater - Charlie Ryall
  - Death Eater - Chloe Franks
  - Death Eater - Chris Knight
  - Death Eater - Courtney Fearon
  - Death Eater - Elisabeth Roberts
  - Death Eater - Emil Hostina
  - Death Eater - Eva Loy
  - Death Eater - Gilbert White
  - Death Eater - Glen Stanway
  - Death Eater - Graham Duff
  - Death Eater - Granville Saxton
  - Death Eater - Hrvoje Klecz
  - Death Eater - Jamie McLeod-Ross
  - Death Eater - Jeff Lipman
  - Death Eater - Joe Kallis
  - Death Eater - Johann Benét
  - Death Eater - Joshua Jo
  - Death Eater - Judith Sharp
  - Death Eater - Kelvin Wise
  - Death Eater - Mason Kayne
  - Death Eater - Matt Da Silva
  - Death Eater - Michael Thompson
  - Death Eater - Natalie Hallam
  - Death Eater - Nick Turner
  - Death Eater - Paul Davies
  - Death Eater - Penelope McGhie
  - Death Eater - Peter G. Reed
  - Death Eater - Rich Goble
  - Death Eater - Sandeep Mohan
  - Death Eater - Timothy Shieff
  - Death Eater - Tony Kirwood
  - Death Eater in Gringotts - Jon Campling
  - Dining Wizard in Painting - David Heyman
  - Draco Malfoy - Tom Felton
  - Dumbledore's Army Member / School Student - Louisa Bettine
  - Engine Driver - Abram Welsh
  - Fenrir Greyback - Dave Legeno
  - Fleur Delacour - Clémence Poésy
  - Fred Weasley - James Phelps
  - George Weasley - Oliver Phelps
  - Giant - Garry Sayer
  - Giant - Phil Wright
  - Giant - Tony Adkins
  - Ginny Weasley - Bonnie Wright
  - Gregory Goyle - Josh Herdman
  - Gringotts Goblin - Adam Alderman
  - Gringotts Goblin - Aimee Holden
  - Gringotts Goblin - Alan Bennett
  - Gringotts Goblin - Andrew Herd
  - Gringotts Goblin - Annabelle Davis
  - Gringotts Goblin - Arti Shah
  - Gringotts Goblin - Binde Johal
  - Gringotts Goblin - Brian Wheeler
  - Gringotts Goblin - Craig Garner
  - Gringotts Goblin - George Appleby
  - Gringotts Goblin - Greg Doherty
  - Gringotts Goblin - Harrison Davis
  - Gringotts Goblin - Hayley Burroughs
  - Gringotts Goblin - Jamie John
  - Gringotts Goblin - Josh Bennett
  - Gringotts Goblin - Karen Anderson
  - Gringotts Goblin - Katie Purvis
  - Gringotts Goblin - Keijo Salmela
  - Gringotts Goblin - Laura Whitfield
  - Gringotts Goblin - Lauren Barrand
  - Gringotts Goblin - Lisa Osmond
  - Gringotts Goblin - Mark Sealey
  - Gringotts Goblin - Maxwell Laird
  - Gringotts Goblin - Michael Henbury Ballan
  - Gringotts Goblin - Mike Edmonds
  - Gringotts Goblin - Nikki Bond
  - Gringotts Goblin - Peter Burroughs
  - Gringotts Goblin - Phil Holden
  - Gringotts Goblin - Ryan Webb
  - Gringotts Goblin - Samantha Davis
  - Gringotts Goblin - Sarah Bennett
  - Gringotts Goblin - Steve Redford
  - Gringotts Guard - Nasir Mohamed
  - Gringotts' Guard - Anthony Allgood
  - Griphook / Professor Filius Flitwick - Warwick Davis
  - Gryffindor Senior - Aaron Virdee
  - Gryffindor Student - Ifeoma Oboko
  - Gryffindor Student - Jordan Coulson
  - Gryffindor Student - Natalie Harrison
  - Gryffindor Student - Paul Bailey
  - Gryffindor Student - Persephone Muse
  - Gryffindor Student - Ryan Butcher
  - Gryffindor Student - Vinnie Clarke
  - Harry Potter - Daniel Radcliffe
  - Helena Ravenclaw - Kelly Macdonald
  - Hermione Granger - Emma Watson
  - Hogsmeade Death Eater - Benn Northover
  - Hogsmeade Death Eater - Ian Peck
  - Hogwart's First Year Epilogue - Melissa Gotobed
  - Hogwarts Student - Daniella Farley
  - Hogwarts Student - Gabriella Pond
  - Hogwarts Student - George Christodoulou
  - Hogwarts Student - Gideon Tekeste
  - Hogwarts Student - Israr Azam
  - Hogwarts Student - Jade Callard
  - Hogwarts Student - Jade Stanger
  - Hogwarts Student - Jonothon Masai
  - Hogwarts Student - Lucy Chappell
  - Hogwarts Student - Matthew Hodgkin
  - Hogwarts Student - Robin Harvey
  - Hogwarts Student - Thomas Alan Williamson
  - Hogwarts Student - Tobi Stubbs
  - Hogwarts Teacher - Albert Tang
  - Hufflepuff Senior - Kamilla Woodburn
  - Hufflepuff Senior - Louisa Warren
  - Hufflepuff Student - Rachel Lin
  - Hugo Weasley - 19 Years Later - Ryan Turner
  - Injured Ravenclaw Student - Chris Chan
  - James Potter - 19 Years Later - Will Dunn
  - James Potter - Adrian Rawlins
  - Katie Bell - Georgina Leonidas
  - Kingsley Shacklebolt - George Harris
  - Knight of Hogwarts - Spencer Wilding
  - Lavender Brown - Jessie Cave
  - Leanne - Isabella Laughland
  - Lily Potter - 19 Years Later - Daphne de Beistegui
  - Lily Potter - Geraldine Somerville
  - Lord Voldemort - Ralph Fiennes
  - Lucius Malfoy - Jason Isaacs
  - Luna Lovegood - Evanna Lynch
  - Madam Pomfrey - Gemma Jones
  - Ministry Wizard - Sarah Lowe
  - Molly Weasley - Julie Walters
  - Muggle / Wizard Parent - Marta Royles
  - Narcissa Malfoy - Helen McCrory
  - Neville Longbottom - Matthew Lewis
  - Nigel - William Melling
  - Nurse Wainscott - Pauline Stone
  - Nymphadora Tonks - Natalia Tena
  - Oliver Wood - Sean Biggerstaff
  - Ollivander - John Hurt
  - One-Legged Wizard - Steven Hopwood
  - Padma Patil - Afshan Azad
  - Pansy Parkinson - Scarlett Hefner
  - Parent - Ben Champniss
  - Passenger - Tony Montalbano
  - Percy Weasley - Chris Rankin
  - Pius Thicknesse - Guy Henry
  - Professor Albus Dumbledore - Michael Gambon
  - Professor Horace Slughorn - Jim Broadbent
  - Professor Minerva McGonagall - Maggie Smith
  - Professor Pomona Sprout - Miriam Margolyes
  - Professor Quirinus Quirrell - Ian Hart
  - Professor Severus Snape - Alan Rickman
  - Professor Sybil Trelawney - Emma Thompson
  - Railway Station Porter - John Warman
  - Ravenclaw Senior - Gemma Kayla
  - Ravenclaw Student - Christina Low
  - Ravenclaw Student - Jessica Niles
  - Remus Lupin - David Thewlis
  - Rionach O'Neal - Marianne Chase
  - Romilda Vane - Anna Shaffer
  - Ron Weasley - Rupert Grint
  - Rose Weasley - 19 Years Later - Helena Barlow
  - Rubeus Hagrid - Robbie Coltrane
  - Scabior - Nick Moran
  - Scorpius Malfoy - 19 Years Later - Bertie Gilbert
  - Screaming Girl - Sian Grace Phillips
  - Seamus Finnigan - Devon Murray
  - Senior Gryffindor - Grace Meurisse Francis
  - Sirius Black - Gary Oldman
  - Slytherin Girl - Sha'ori Morris
  - Slytherin School Girl - Isla Jane Selley
  - Slytherin Student - Amy Wiles
  - Slytherin Student - Dean Conder
  - Slytherin Student - Leila Kotori
  - Slytherin Student - Roseanna Brown
  - Snatcher - Adam Brashaw
  - Snatcher - Chloé Bruce
  - Snatcher - Christian Black
  - Snatcher - Christoph Cordell
  - Snatcher - Collet Collins
  - Snatcher - Curtis Rowland Small
  - Snatcher - Grace Bruce
  - Snatcher - Jennifer Clegg
  - Snatcher - Nathan Barris
  - Snatcher - Samuel Supple
  - Student - Blake Curtis-Woodcock
  - Student - Charlie Hobbs
  - Student - David Ledger
  - Student - Lily Tello
  - Student - Sammy Measom
  - Student - Victor Akintunde
  - Student - Zoltan Adorjan
  - Teddy Lupin - Luke Newberry
  - The Sorting Hat - Leslie Phillips
  - Tom Marvolo Riddle - Christian Coulson
  - Train Passenger - Gino Picciano
  - Twin Girl 1 - Amber Evans
  - Twin Girl 2 - Ruby Evans
  - Wendy Slinkhard - Nina Aimer Fox
  - Wizard - Alfred Camp
  - Wizard Parent - Andy Callaghan
  - Wizard Parent - Gioacchino Jim Cuffaro
  - Wizard Parent - Mark Dusty Miller
  - Wizard Parent - Michael Aston
  - Wizard Parent - Nick Hopper
  - Wizard Parent - Paul Bateman
  - Wizard Parent - Sarah-Jane De Crespigny
  - Wizard Parent - Sean Francis George
  - Wizard Parent - Valerie Dane
  - Wizard Teacher - Debra Leigh-Taylor
  - Wizard Teacher - Steve Poulsen
  - Wizard with Dog in Painting - David Barron
  - Wormtail - Timothy Spall
  - Young Girl in Epilogue - Hattie Gotobed
  - Young James Potter - Alfie McIlwain
  - Young Lily Potter - Ellie Darcey-Alden
  - Young Petunia Dursley - Ariella Paradise
  - Young Severus Snape - Benedict Clarke
  - Young Sirius Black - Rohan Gotobed
Кинопоиск ID: "407636"
---
<!-- KINO:ENTITY:LINKS:V3 -->
```dataviewjs
const KINO_ENTITY_FIELDS = [
    ["Режисер", "Режиссер", "Кино - Открыть режиссера"],
    ["Актеры", "Актеры", "Кино - Открыть актера"],
    ["Жанр", "Жанры", "Кино - Открыть жанр"]
];

function kinoText(value) { return String(value ?? "").trim().normalize("NFC"); }
function kinoValues(value) {
    return [...new Set((Array.isArray(value) ? value : [value]).map(kinoText).filter(Boolean))];
}
function kinoName(value) {
    const text = kinoText(value);
    const actorNames = kinoValues(dv.current()["Актеры"]);
    const known = actorNames.find(name =>
        text === name || text.startsWith(name + " - ") || text.endsWith(" - " + name)
    );
    if (known) return known;
    return text.includes(" - ") ? text.split(/\s+-\s+/).slice(-1)[0].trim() : text;
}
function kinoUri(choice, value) {
    return "obsidian://quickadd?vault=" + encodeURIComponent(app.vault.getName())
        + "&choice=" + encodeURIComponent(choice)
        + "&value-entity=" + encodeURIComponent(value);
}

const actorRoles = kinoValues(dv.current()["Роли актеров"]);
const root = dv.container.createDiv({ cls: "kino-entity-links" });
for (const [field, label, choice] of KINO_ENTITY_FIELDS) {
    const row = root.createDiv({ cls: "kino-entity-links-row" });
    row.createEl("strong", { text: label + ": " });
    const values = field === "Актеры"
        ? (actorRoles.length ? actorRoles : kinoValues(dv.current()[field]))
        : kinoValues(dv.current()[field]);
    if (!values.length) { row.appendText("Не указано"); continue; }
    if (field === "Актеры") {
        values.forEach(value => {
            const line = row.createDiv({ cls: "kino-entity-link-line" });
            const link = line.createEl("a");
            link.textContent = value;
            link.href = kinoUri(choice, kinoName(value));
        });
        continue;
    }
    values.forEach((value, index) => {
        if (index) row.appendText(" · ");
        const link = row.createEl("a");
        link.textContent = value;
        link.href = kinoUri(choice, value);
    });
}
```
---

---
![](https://m.media-amazon.com/images/M/MV5BOTA1Mzc2N2ItZWRiNS00MjQzLTlmZDQtMjU0NmY1YWRkMGQ4XkEyXkFqcGc@._V1_SX300.jpg)
