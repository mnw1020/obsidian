---
Название: Into the Universe with Stephen Hawking
Просмотрено: 2013-12-20
Оценка: "6"
Оценка Imdb: "8.5"
Оценка Кинопоиск: 8.5
Количество голосов Кинопоиск: 5797
Количество голосов Imdb: 5704
tags:
  - serial
Жанр:
  - Documentary
Релиз: 2010-04-25
Время: 43 min
Режисер:
  - Iain Riddick
  - Martin Williams
  - Nathan Williams

Роли файл: "Кино/_system/Роли/Discovery - Во Вселенную со Стивеном Хокингом.роли.md"
Описание: Знаменитый физик, профессор Стивен Хокинг, который в 30 лет оказался практически полностью парализован из-за прогрессирующей болезни, делится мыслями о самых интригующих загадках Вселенной, таких как инопланетная жизнь или путешествие во времени.
imdb Id: tt1655078
poster: https://m.media-amazon.com/images/M/MV5BMTkyNTAwMTk2Ml5BMl5BanBnXkFtZTgwMDA2NjE0MzE@._V1_.jpg

Кинопоиск ID: "542489"
---
<!-- KINO:ROLES:EMBED:V1 -->
![[Кино/_system/Роли/Discovery - Во Вселенную со Стивеном Хокингом.роли]]
![](https://m.media-amazon.com/images/M/MV5BMTkyNTAwMTk2Ml5BMl5BanBnXkFtZTgwMDA2NjE0MzE@._V1_.jpg)
