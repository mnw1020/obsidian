---
Название: "Zombieland: Double Tap"
Просмотрено: 2024-01-11
Оценка: "7"
Оценка Imdb: "6.6"
Оценка Кинопоиск: 6.7
Количество голосов Кинопоиск: 206554
Количество голосов Imdb: 229654
tags:
  - movies
Жанр:
  - Action
Релиз: 2019-10-09
Время: 99 min
Режисер:
  - Ruben Fleischer

Роли файл: "Кино/_system/Роли/Zомбилэнд - Контрольный выстрел.роли.md"
Описание: Беспощадная и бесстрашная четверка охотников на зомби продолжает свое путешествие в глубь страны. На этот раз им предстоит сразиться не только с новыми видами живых мертвецов, но и познакомиться с другими выжившими. Кроме того, в собственных рядах наших героев намечается серьезный разлад.
imdb Id: tt1560220
poster: https://m.media-amazon.com/images/M/MV5BOTViNDc4NTgtYzVlNi00YmY3LWFiNDgtODJlNGU1YzI1MGExXkEyXkFqcGc@._V1_SX300.jpg
Франшиза: "[[Кино/Франшизы/Зомбилэнд]]"

---
<!-- KINO:ROLES:EMBED:V1 -->
![[Кино/_system/Роли/Zомбилэнд - Контрольный выстрел.роли]]
![](https://m.media-amazon.com/images/M/MV5BOTViNDc4NTgtYzVlNi00YmY3LWFiNDgtODJlNGU1YzI1MGExXkEyXkFqcGc@._V1_SX300.jpg)
