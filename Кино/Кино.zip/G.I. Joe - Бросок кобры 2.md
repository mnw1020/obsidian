---
Название: "G.I. Joe: Retaliation"
Просмотрено: 2013-07-17
Оценка: "6"
Оценка Imdb: "5.7"
Оценка Кинопоиск: 5.8
Количество голосов Кинопоиск: 87972
Количество голосов Imdb: 194115
tags:
  - movies
Жанр:
  - Sci-Fi
Релиз: 2013-03-11
Время: 110 min
Режисер:
  - Jon M. Chu

Роли файл: "Кино/_system/Роли/G.I. Joe - Бросок кобры 2.роли.md"
Описание: Во второй части отряд «G.I. Joe» вновь объявит вызов группировке «Кобра» и вступит в противостояние с правительством.
imdb Id: tt1583421
poster: https://m.media-amazon.com/images/M/MV5BNzk5ODM0OTQ0N15BMl5BanBnXkFtZTcwODg2ODE4OA@@._V1_.jpg
Франшиза: "[[Кино/Франшизы/G.I. Joe]]"

Кинопоиск ID: "494839"
---
<!-- KINO:ROLES:EMBED:V1 -->
![[Кино/_system/Роли/G.I. Joe - Бросок кобры 2.роли]]
![](https://m.media-amazon.com/images/M/MV5BNzk5ODM0OTQ0N15BMl5BanBnXkFtZTcwODg2ODE4OA@@._V1_.jpg)
